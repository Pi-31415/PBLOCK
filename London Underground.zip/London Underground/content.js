/**
 * URL Filter for Browser
 * 
 * Author: Pi Ko (pi.ko@nyu.edu)
 * Date: 29 July 2024
 * 
 * This script redirects pages containing specific keywords in their URL to google.com
 */

// Debug flag - set to true to enable console logging
const DEBUG_MODE = true;

/**
 * Logs debug information to console if debug mode is enabled
 * @param {string} message - Message to log
 * @param {any} data - Optional data to log
 */
function debugLog(message, data = null) {
  if (!DEBUG_MODE) return;
  
  if (data) {
    console.log(`[DEBUG] ${message}`, data);
  } else {
    console.log(`[DEBUG] ${message}`);
  }
}

// Log that extension is loaded
debugLog('Content script loaded and running');

// List of domains to block
const blockedDomains = [
  'nordvpn.com',
  'expressvpn.com',
  'surfshark.com',
  'norton.com',
  'mullvad.net',
  'protonvpn.com',
  'privateinternetaccess.com',
  'tunnelbear.com',
  'windscribe.com',
  'obscuravpn.com',
  'nymtech.net',
  'cyberghostvpn.com',
  'ipvanish.com',
  'hotspotshield.com',
  'purevpn.com',
  'ivpn.net',
  'privadovpn.com',
  'hide.me',
  'atlasvpn.com',
  'vyprvpn.com',
  'betternet.co',
  'torguard.net',
  'strongvpn.com',
  'ultravpn.com',
  'slickvpn.com',
  'frootvpn.com',
  'zoogvpn.com',
  'browsec.com',
  'turbovpn.com',
  'dotvpn.com',
  'kaspersky.com',
  'avast.com',
  'avg.com',
  'avira.com',
  'mcafee.com',
  'bitdefender.com',
  'f-secure.com',
  'pandasecurity.com',
  'zonealarm.com',
  'comodo.com',
  'emsisoft.com',
  'malwarebytes.com',
  'superantispyware.com',
  'spybot.com',
  'adaware.com',
  'iobit.com',
  'glarysoft.com',
  'piriform.com',
  'bleepingcomputer.com',
  'majorgeeks.com',
  'techspot.com',
  'filehippo.com',
  'softpedia.com',
  'cnet.com',
  'download.com',
  'snapfiles.com',
  'freewarefiles.com',
  'filehorse.com',
  'softonic.com',
  'techradar.com',
  'lifewire.com'
];

debugLog('Loaded blocked domains list', blockedDomains.length);

// Keywords to block
const blockedKeywords = ['vpn', 'porn', 'xxx', 'xnxx', 'proxy', 'unblocker', 'unblock'];

debugLog('Loaded blocked keywords list', blockedKeywords);

/**
 * Checks if the current URL contains any blocked domains or keywords
 * @returns {boolean} - True if the URL should be blocked
 */
function shouldBlockURL() {
  const currentURL = window.location.href.toLowerCase();
  
  debugLog('Checking URL', currentURL);
  
  // Special handling for Chrome Web Store
  if (currentURL.includes('chromewebstore.google.com')) {
    debugLog('URL is from Chrome Web Store, checking content');
    
    // For Chrome Web Store, we want to check for VPN extensions specifically
    if (blockedKeywords.some(keyword => currentURL.includes(keyword))) {
      debugLog('Chrome Web Store URL contains blocked keyword');
      return true;
    }
    
    // Also check if it's a detail page for an extension with blocked terms in the path
    if (currentURL.includes('/detail/') && 
        blockedKeywords.some(keyword => currentURL.includes(keyword))) {
      debugLog('Chrome Web Store detail page contains blocked keyword');
      return true;
    }
  } 
  // Don't block Google itself (except Chrome Web Store VPN pages)
  else if (currentURL.includes('google.com')) {
    debugLog('URL belongs to Google, not blocking');
    return false;
  }
  
  // Check for blocked domains
  for (const domain of blockedDomains) {
    if (currentURL.includes(domain)) {
      debugLog(`URL contains blocked domain: ${domain}`);
      return true;
    }
  }
  
  // Check for blocked keywords
  for (const keyword of blockedKeywords) {
    if (currentURL.includes(keyword)) {
      debugLog(`URL contains blocked keyword: ${keyword}`);
      return true;
    }
  }
  
  debugLog('URL is acceptable');
  return false;
}

/**
 * Redirects to Google.com
 */
function redirectToGoogle() {
  debugLog('Redirecting to Google.com');
  window.location.replace('https://www.google.com');
}

/**
 * Main function that runs on page load
 */
function main() {
  debugLog('Running main check function');
  
  if (shouldBlockURL()) {
    debugLog('URL should be blocked, initiating redirect');
    redirectToGoogle();
  } else {
    debugLog('URL passed checks, allowing page to load');
  }
}

// Track navigation events including history changes
function setupEventListeners() {
  debugLog('Setting up event listeners');
  
  // Listen for all navigation events
  window.addEventListener('popstate', () => {
    debugLog('History state changed (popstate event)');
    main();
  });
  
  window.addEventListener('hashchange', () => {
    debugLog('URL hash changed (hashchange event)');
    main();
  });
  
  // Check again when the page is fully interactive
  document.addEventListener('DOMContentLoaded', () => {
    debugLog('DOM content loaded (DOMContentLoaded event)');
    main();
  });
  
  // Recheck when any document body updates occur
  if (document.body) {
    debugLog('Document body available, setting up mutation observer');
    const observer = new MutationObserver(() => {
      debugLog('DOM mutation detected');
      main();
    });
    
    observer.observe(document.body, {
      childList: true,
      subtree: true
    });
    debugLog('Mutation observer started');
  } else {
    // If document.body isn't available yet, wait for it
    debugLog('Document body not available, will set up observer after DOMContentLoaded');
    document.addEventListener('DOMContentLoaded', () => {
      debugLog('Document now interactive, setting up delayed mutation observer');
      const observer = new MutationObserver(() => {
        debugLog('DOM mutation detected (delayed observer)');
        main();
      });
      
      observer.observe(document.body, {
        childList: true,
        subtree: true
      });
      debugLog('Delayed mutation observer started');
    });
  }
}

// Initial check immediately on script load
debugLog('Performing initial URL check');
main();

// Set up listeners for navigation changes
setupEventListeners();
debugLog('Initialization complete'); 