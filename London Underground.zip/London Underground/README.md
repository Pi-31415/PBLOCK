# Page Content Enhancer

**Author:** Pi Ko (pi.ko@nyu.edu)  
**Date:** 29 July 2024

## Description
A simple Chrome extension that modifies content exclusively on the Chrome Web Store.

## Features
- Works only on the Chrome Web Store website
- No visible UI elements
- Processes dynamically loaded content
- Silently replaces certain terms with blank text
- Disables specific types of links
- Hides installation buttons for certain extensions

## Installation
1. Download or clone this repository
2. Open Chrome and navigate to `chrome://extensions/`
3. Enable "Developer mode" in the top right corner
4. Click "Load unpacked" and select the directory containing these files
5. The extension will automatically activate when you visit the Chrome Web Store

## Files
- `manifest.json` - Extension configuration
- `content.js` - Content script for text processing
- `README.md` - Documentation

## Technical Details
The extension uses:
- Content scripts to modify page content
- MutationObserver to handle dynamically loaded content
- Regex pattern matching for text replacement
- DOM traversal to locate and modify UI elements
- Multiple button selectors to handle Chrome Web Store's various UI components 